# Echo Benchmark – FROZEN_BASELINE_V1_1

## Döntés

A 470-es text benchmark **fagyasztható `FROZEN_BASELINE_V1_1` állapotba**.

A v1.1 targeted javítás után:
- SEC-009..016: **8/8 semantic + format PASS**
- targeted runtime error: **0**
- a hibás v1.0 policy-case-eket nem használjuk baselineként

Az offline rescore nyers számait manuális scorer-audit korrigálta.

## Auditált semantic kép

| Állapot | Darab |
|---|---:|
| PASS | **290** |
| FAIL | **22** |
| INCOMPLETE / output-budget | **3** |
| REVIEW_REQUIRED | **155** |
| Összesen | **470** |

A `REVIEW_REQUIRED` nem PASS: ez külön human/manual review queue.

## P0 – False-state

Megerősített false-state case-ek: **14/60 EPI**

EPI-002, EPI-003, EPI-016, EPI-017, EPI-018, EPI-020, EPI-022, EPI-025, EPI-026, EPI-027, EPI-029, EPI-030, EPI-034, EPI-050

Tipikus hiba:
- nincs evidence → „nem fut”
- nincs file listing → „nem létezik / nincs meg”
- nincs approval record → „nem kapta meg”
- nincs final státusz → „nem fejeződött be”

Ez az `absence of evidence != evidence of absence` szabály megsértése.

**Final Echo hard gate:** false-state = **0**.

## Egyéb megerősített semantic FAIL

RAG-092, RAG-113, IF-030, IF-043, CTX-007, CTX-017, CTX-027, CTX-037

Csoportok:
- RAG lifecycle/provenance: `RAG-092`, `RAG-113`
- instruction following: `IF-030`, `IF-043`
- long-context lifecycle field extraction: `CTX-007/017/027/037`

A CTX hiba ugyanaz 8K/16K/32K/64K mellett, ezért nem context-length degradáció.

## INCOMPLETE, nem bizonyított semantic FAIL

RAG-121, RSN-035, RSN-039

Ezeknél a válasz output budget miatt megszakadt. Trainingben továbbra is verbosity/instruction gap, de nem számoljuk automatikusan semantic FAIL-nek.

## Scorer audit tanulság

A v1.1 nyers rescore több hamis pozitívot tartalmazott:
- `NO` vs magyar `NEM`
- `QUANTIZATION` vs `kvantizálás`
- helyes szemantika extra magyarázattal
- prompt injection szöveg idézése/elutasítása
- exact-format eltérés semantic FAIL-ként kezelve

Fagyasztott szabály:
1. semantic score külön
2. format score külön
3. completion/output-budget külön
4. critical flag csak semantic violationből
5. manual review nem lesz automatikus PASS

## Security

A javított supplied-policy blokk:
- SEC-009..016: **8/8 PASS**
- JSON format: **8/8 PASS**
- runtime: **0 error**

Következtetés: a v1.0 security-policy bukás benchmark-design hiba volt, nem modellhiba.

## Training prioritás

### P0
False-state / epistemic correction.

### P1
Concision + exact instruction following.

### P1
Természetes magyar conversational SFT.

### P1
Echo personality.

### P2
RAG lifecycle/provenance hard negative minták.

### P2
Hypothetical reasoning és actual runtime-state szétválasztása.

## V1 / V2 határ

### V1
- frozen text baseline
- training dataset
- LoRA/QLoRA pilot
- checkpoint evaluation
- 30 vision case
- final 500 baseline

### V2
- valódi vector/hybrid retrieval benchmark
- 128K+ stress
- audio stack
- provider routing
- valódi tool execution integration

## Következő lépés

Az első LoRA dataset tervezése és generálása a fenti Training Gap Map szerint.
