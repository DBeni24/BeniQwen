﻿$ErrorActionPreference = "Stop"
$Root=Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root
$Python=Join-Path $Root ".venv\Scripts\python.exe"
if (-not (Test-Path $Python)) { throw "Nem talalom a .venv-et." }
& $Python -m scorers.selftest
if ($LASTEXITCODE -ne 0) { throw "Scorer self-test FAIL." }
$PsJson=(& lms ps --json 2>&1 | Out-String)
if ($PsJson -notmatch '"identifier":"echo-qwen-baseline"') {
  Write-Host "A baseline modell nincs betoltve; betoltes 8K contexttel..." -ForegroundColor Yellow
  & lms load qwen/qwen3.5-9b --gpu max --context-length 8192 --identifier echo-qwen-baseline
  if ($LASTEXITCODE -ne 0) { throw "Model load FAIL." }
}
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " ECHO QWEN BASELINE - FULL470 TEXT" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "A futas resume-kepes. Megszakitas utan ugyanazt a parancsot futtasd ujra."
& $Python .\runner\run_full470.py
if ($LASTEXITCODE -ne 0) { throw "Full470 runner hibaval allt le." }
Write-Host ""
if (Test-Path ".\UPLOAD_ME_ECHO_FULL470.zip") {
  Write-Host "Feltoltendo fajl:" -ForegroundColor Green
  Write-Host (Join-Path $Root "UPLOAD_ME_ECHO_FULL470.zip")
} else {
  Write-Host "A run nem teljes. Ujrafuttatva folytatja a meglevot." -ForegroundColor Yellow
}
