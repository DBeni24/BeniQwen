﻿$ErrorActionPreference = "Stop"
$Source = Split-Path -Parent $MyInvocation.MyCommand.Path
$Target = Read-Host "Add meg az echo_qwen_baseline_v1_environment mappa teljes eleresi utjat"
if (-not (Test-Path $Target)) { throw "A celmappa nem letezik." }
foreach ($Folder in @("cases","rag_packs","config","scorers","runner","docs","holdout")) {
  $Src=Join-Path $Source $Folder
  if (Test-Path $Src) {
    $Dst=Join-Path $Target $Folder; New-Item -ItemType Directory -Force -Path $Dst | Out-Null
    Copy-Item -Path (Join-Path $Src "*") -Destination $Dst -Recurse -Force
  }
}
Copy-Item (Join-Path $Source "RUN-FULL470.ps1") $Target -Force
Copy-Item (Join-Path $Source "README_FULL470.md") $Target -Force
Write-Host "Full470 telepitve:" -ForegroundColor Green
Write-Host $Target
