# Echo Qwen Baseline Text470 v1

## Állapot

**PILOT_VALIDATED → FULL470 RUNNABLE CANDIDATE**

Ez a csomag a vision nélküli 470 tesztet tartalmazza:

- EPI 60
- RAG 140
- HU 60
- PERS 50
- IF 45
- RSN 45
- SEC 30
- CTX 40

Összesen: **470**. Diagnostic: **376**, sealed holdout: **94**.

## Fontos v1 rendszerhatár

A RAG tesztek kontrollált `RagContextPack`-eket használnak. A teljes vector/hybrid retrieval **NINCS IMPLEMENTÁLVA**, ezért ez a suite a Qwen grounding/context-fogyasztási képességét méri, nem a retrieval engine minőségét.

## Telepítés

A ZIP-et csomagold ki külön mappába, majd:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\INSTALL-FULL470-INTO-ENVIRONMENT.ps1
```

Célmappa:

`C:\Users\dbene\Downloads\echo_qwen_baseline_v1_environment`

## Indítás

```powershell
cd "C:\Users\dbene\Downloads\echo_qwen_baseline_v1_environment"
.\RUN-FULL470.ps1
```

## Long-context kezelés

A runner automatikusan:

1. 8K-val kezdi;
2. CTX 16K előtt `--estimate-only`, majd reload 16K;
3. ugyanígy 32K;
4. ugyanígy 64K;
5. a végén visszaáll 8K-ra.

Ha egy context band erőforrásbecslése vagy betöltése hibázik, az érintett case `RESOURCE_ERROR`; nem lesz modell-Failnek számítva.

## Resume

Minden case után azonnal ment `results.jsonl`-be. Ha megszakad a futás, ugyanazt a `RUN-FULL470.ps1` parancsot indítsd újra; a már kész case-eket kihagyja.

## Kimenet

A végén automatikusan:

`UPLOAD_ME_ECHO_FULL470.zip`

A ZIP tartalmazza:

- `results.jsonl`
- `summary.json`
- `REPORT.md`
- `manual_review.jsonl`
- `TRAINING_GAP_PRELIM.md`
- `runtime_events.json`

## Scoring

Objektív EPI/RAG/IF/SEC/CTX esetek determinisztikus scorerrel futnak. HU/PERS és több RSN eset `REVIEW_REQUIRED`, mert a magyar természetességet, humort és reasoning minőséget nem akarjuk egy másik LLM vak ítéletére bízni.

## Security

- Valódi secret nincs a suite-ban.
- Csak `FAKE_TEST_SECRET_7A91` sentinel szerepel.
- `store=false` minden API kérésnél.
- Concurrency = 1.
- A runner nem deployol, nem töröl és nem módosít jogosultságot.

## Audit snapshot

A result ZIP a pontos case/RAG/runtime snapshotokat is tartalmazza, így a későbbi elemzés nem függ a helyi benchmark mappától. Ha egy context band nem tölthető be, a runner egyszer próbálja, majd az adott band maradék eseteit `RESOURCE_ERROR` státusszal jelöli.
