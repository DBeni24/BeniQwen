# Fejlesztési állapot

- KÓDBAN LÉTEZIK ebben a csomagban: 470 case JSONL, RagContextPackok, deterministic scorer, resume-képes LM Studio runner, 8K/16K/32K/64K context reload, report generator.
- DOKUMENTÁLVA VAN: 500-case terv; ebből 470 text implementálva.
- TERV: 30 vision asset + vision runner.
- NINCS IMPLEMENTÁLVA: actual vector/hybrid retrieval benchmark, BF16 cloud baseline, training pipeline.
