﻿$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path

$KnownPython = "C:\Users\dbene\Downloads\echo_qwen_baseline_v1_environment\.venv\Scripts\python.exe"
if (Test-Path $KnownPython) {
    $Python = $KnownPython
} else {
    $Cmd = Get-Command python -ErrorAction SilentlyContinue
    if (-not $Cmd) { throw "Nem talalok hasznalhato Python kornyezetet." }
    $Python = $Cmd.Source
}

& $Python (Join-Path $Root "tools\validate_dataset_r2.py")
if ($LASTEXITCODE -ne 0) { throw "Dataset R2 validator FAIL." }
