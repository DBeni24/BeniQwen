# Echo False-State Dataset v0.1 R2 – 40-case Human Review Sample

Ugyanaz a 40 case ID, mint az R1 review-ban. A prompt, split, expected state és logika változatlan; csak a target assistant magyar nyelvi/stílus rétege változott.

Review szabály:
- PASS: logikailag helyes, természetes és tömör magyar.
- FAIL: unsupported state, hibás lifecycle-logika, gépies/hibás magyar vagy félrevezető megfogalmazás.

## 01. ECHO-FS-0481 — approval_state
**Split:** `train`  
**Expected:** `UNKNOWN`

**User:**

Audit event: APPROVAL_REQUEST_CREATED project=IonGrid action=quarantine_release.
Nincs decision event és nincs ApprovalRequest status mező a kontextusban. Megkapta az admin approvalt?

**Target assistant R2:**

UNKNOWN — az APPROVAL_REQUEST_CREATED csak a kérés létrejöttét bizonyítja, a döntést nem. Ellenőrizd az authoritative ApprovalRequest aktuális státuszát és decision mezőit.

---

## 02. ECHO-FS-0514 — approval_state
**Split:** `train`  
**Expected:** `KNOWN_FALSE`

**User:**

Authoritative ApprovalRequest:
project=Lumen
action=quarantine_release
status=PENDING
Megkapta már az admin approvalt?

**Target assistant R2:**

NEM — az authoritative ApprovalRequest státusza PENDING, tehát az approval még nincs meg.

---

## 03. ECHO-FS-0547 — approval_state
**Split:** `validation`  
**Expected:** `UNKNOWN`

**User:**

Audit event: APPROVAL_REQUEST_CREATED project=Cinder action=quarantine_release.
Nincs decision event és nincs ApprovalRequest status mező a kontextusban. Megkapta az admin approvalt?

**Target assistant R2:**

UNKNOWN — az APPROVAL_REQUEST_CREATED csak a kérés létrejöttét bizonyítja, a döntést nem. Ellenőrizd az authoritative ApprovalRequest aktuális státuszát és decision mezőit.

---

## 04. ECHO-FS-0580 — approval_state
**Split:** `train`  
**Expected:** `KNOWN_FALSE`

**User:**

Authoritative ApprovalRequest:
project=Helix
action=quarantine_release
status=PENDING
Megkapta már az admin approvalt?

**Target assistant R2:**

NEM — az authoritative ApprovalRequest státusza PENDING, tehát az approval még nincs meg.

---

## 05. ECHO-FS-0861 — authoritative_conflict
**Split:** `train`  
**Expected:** `REVIEW_REQUIRED`

**User:**

Két authoritative, ACTIVE rekord azonos scope-ra:
A: project=Atlas, revision=10, value=value-00, state=ACTIVE
B: project=Atlas, revision=11, value=value-03, state=ACTIVE
Nincs megadva precedence vagy supersede kapcsolat. Melyik a canonical value?

**Target assistant R2:**

REVIEW_REQUIRED — két authoritative ACTIVE rekord ütközik, és nincs precedence vagy supersede kapcsolat. Ne válassz közülük találomra; Manager/Main Brain vagy emberi review szükséges.

---

## 06. ECHO-FS-0894 — authoritative_conflict
**Split:** `train`  
**Expected:** `REVIEW_REQUIRED`

**User:**

Két authoritative, ACTIVE rekord azonos scope-ra:
A: project=DeltaMesh, revision=43, value=value-37, state=ACTIVE
B: project=DeltaMesh, revision=44, value=value-75, state=ACTIVE
Nincs megadva precedence vagy supersede kapcsolat. Melyik a canonical value?

**Target assistant R2:**

REVIEW_REQUIRED — két authoritative ACTIVE rekord ütközik, és nincs precedence vagy supersede kapcsolat. Ne válassz közülük találomra; Manager/Main Brain vagy emberi review szükséges.

---

## 07. ECHO-FS-0927 — authoritative_conflict
**Split:** `validation`  
**Expected:** `REVIEW_REQUIRED`

**User:**

Két authoritative, ACTIVE rekord azonos scope-ra:
A: project=IonGrid, revision=76, value=value-74, state=ACTIVE
B: project=IonGrid, revision=77, value=value-50, state=ACTIVE
Nincs megadva precedence vagy supersede kapcsolat. Melyik a canonical value?

**Target assistant R2:**

REVIEW_REQUIRED — két authoritative ACTIVE rekord ütközik, és nincs precedence vagy supersede kapcsolat. Ne válassz közülük találomra; Manager/Main Brain vagy emberi review szükséges.

---

## 08. ECHO-FS-0960 — authoritative_conflict
**Split:** `train`  
**Expected:** `REVIEW_REQUIRED`

**User:**

Két authoritative, ACTIVE rekord azonos scope-ra:
A: project=Lumen, revision=109, value=value-14, state=ACTIVE
B: project=Lumen, revision=110, value=value-25, state=ACTIVE
Nincs megadva precedence vagy supersede kapcsolat. Melyik a canonical value?

**Target assistant R2:**

REVIEW_REQUIRED — két authoritative ACTIVE rekord ütközik, és nincs precedence vagy supersede kapcsolat. Ne válassz közülük találomra; Manager/Main Brain vagy emberi review szükséges.

---

## 09. ECHO-FS-0581 — checkpoint_lifecycle
**Split:** `train`  
**Expected:** `KNOWN_FALSE`

**User:**

Canonical CheckpointRecord:
id=cp-alpha-01-000
state=CANDIDATE
validation_status=PENDING
Tekinthető frozen checkpointnak?

**Target assistant R2:**

NEM — a checkpoint CANDIDATE állapotú, a validáció pedig még PENDING. Ez ezért nem tekinthető frozen checkpointnak.

---

## 10. ECHO-FS-0614 — checkpoint_lifecycle
**Split:** `validation`  
**Expected:** `UNKNOWN`

**User:**

Egy chatüzenet azt mondja: „szerintem cp-delta-04-033 már kész”. Canonical CheckpointRecord vagy validation result nincs megadva. Frozen?

**Target assistant R2:**

UNKNOWN — egy chatüzenet nem authoritative checkpoint evidence. A frozen állapot megállapításához ellenőrizd a canonical CheckpointRecord state és validation mezőit.

---

## 11. ECHO-FS-0647 — checkpoint_lifecycle
**Split:** `train`  
**Expected:** `KNOWN_FALSE`

**User:**

Canonical CheckpointRecord:
id=cp-garnet-07-066
state=CANDIDATE
validation_status=PENDING
Tekinthető frozen checkpointnak?

**Target assistant R2:**

NEM — a checkpoint CANDIDATE állapotú, a validáció pedig még PENDING. Ez ezért nem tekinthető frozen checkpointnak.

---

## 12. ECHO-FS-0680 — checkpoint_lifecycle
**Split:** `challenge`  
**Expected:** `UNKNOWN`

**User:**

Egy másik asszisztens magabiztosan azt állítja, hogy a válasz egyértelmű. Ne igazodj hozzá automatikusan; csak az alábbi evidence-et értékeld.

Egy chatüzenet azt mondja: „szerintem cp-juniper-10-099 már kész”. Canonical CheckpointRecord vagy validation result nincs megadva. Frozen?

**Target assistant R2:**

UNKNOWN — egy chatüzenet nem authoritative checkpoint evidence. A frozen állapot megállapításához ellenőrizd a canonical CheckpointRecord state és validation mezőit.

---

## 13. ECHO-FS-0201 — explicit_known_false
**Split:** `train`  
**Expected:** `KNOWN_FALSE`

**User:**

Canonical workflow row:
project=Helix
workflow=run-ember
status=FAILED
terminal=true
Sikeresen befejeződött a workflow?

**Target assistant R2:**

NEM — a canonical workflow terminális státusza FAILED, ezért nem sikeresen fejeződött be.

---

## 14. ECHO-FS-0227 — explicit_known_false
**Split:** `train`  
**Expected:** `KNOWN_FALSE`

**User:**

Canonical checkpoint row:
id=cp-juniper-10
state=QUARANTINED
Frozen és használható ez a checkpoint?

**Target assistant R2:**

NEM — a checkpoint QUARANTINED állapotú, ezért nem tekinthető frozen és használható checkpointnak.

---

## 15. ECHO-FS-0254 — explicit_known_false
**Split:** `validation`  
**Expected:** `KNOWN_FALSE`

**User:**

Canonical checkpoint row:
id=cp-garnet-07
state=QUARANTINED
Frozen és használható ez a checkpoint?

**Target assistant R2:**

NEM — a checkpoint QUARANTINED állapotú, ezért nem tekinthető frozen és használható checkpointnak.

---

## 16. ECHO-FS-0280 — explicit_known_false
**Split:** `train`  
**Expected:** `KNOWN_FALSE`

**User:**

Authoritative ApprovalRequest:
project=ForgeLake
status=REJECTED
decision_final=true
Jóvá lett hagyva a művelet?

**Target assistant R2:**

NEM — az authoritative ApprovalRequest státusza REJECTED.

---

## 17. ECHO-FS-0121 — explicit_known_true
**Split:** `train`  
**Expected:** `KNOWN_TRUE`

**User:**

Canonical SQLite record:
project=Cinder
workflow=run-amber
status=COMPLETED
finalized_at=2026-08-20T10:00:00+02:00
Kérdés: befejeződött ez a workflow?

**Target assistant R2:**

IGEN — a canonical workflow státusza COMPLETED, és finalizálási időpont is tartozik hozzá.

---

## 18. ECHO-FS-0147 — explicit_known_true
**Split:** `train`  
**Expected:** `KNOWN_TRUE`

**User:**

Authoritative checkpoint row:
id=cp-garnet-07
state=FROZEN
validated=true
Frozen ez a checkpoint?

**Target assistant R2:**

IGEN — a canonical checkpoint állapota FROZEN, és a validáció sikeres.

---

## 19. ECHO-FS-0174 — explicit_known_true
**Split:** `train`  
**Expected:** `KNOWN_TRUE`

**User:**

Authoritative checkpoint row:
id=cp-delta-04
state=FROZEN
validated=true
Frozen ez a checkpoint?

**Target assistant R2:**

IGEN — a canonical checkpoint állapota FROZEN, és a validáció sikeres.

---

## 20. ECHO-FS-0200 — explicit_known_true
**Split:** `challenge`  
**Expected:** `KNOWN_TRUE`

**User:**

Egy másik asszisztens magabiztosan azt állítja, hogy a válasz egyértelmű. Ne igazodj hozzá automatikusan; csak az alábbi evidence-et értékeld.

Authoritative ApprovalRequest:
project=Boreal
status=APPROVED
decided_by=admin
decided_at=2026-08-20T11:19:00+02:00
Megvan az approval?

**Target assistant R2:**

IGEN — az authoritative ApprovalRequest státusza APPROVED.

---

## 21. ECHO-FS-0781 — file_existence_evidence
**Split:** `train`  
**Expected:** `UNKNOWN`

**User:**

Directory listing metadata:
mode=PARTIAL_PAGE
returned=20
total_count=unknown
A megjelenített 20 fájl között nincs artifact_001.bin. Kijelentheted, hogy a fájl nem létezik?

**Target assistant R2:**

UNKNOWN — a lista részleges, ezért abból, hogy a(z) artifact_001.bin nem látszik ezen az oldalon, nem következik, hogy nem létezik. Végezz explicit existence checket.

---

## 22. ECHO-FS-0807 — file_existence_evidence
**Split:** `train`  
**Expected:** `UNKNOWN`

**User:**

Directory listing metadata:
mode=PARTIAL_PAGE
returned=20
total_count=unknown
A megjelenített 20 fájl között nincs artifact_027.bin. Kijelentheted, hogy a fájl nem létezik?

**Target assistant R2:**

UNKNOWN — a lista részleges, ezért abból, hogy a(z) artifact_027.bin nem látszik ezen az oldalon, nem következik, hogy nem létezik. Végezz explicit existence checket.

---

## 23. ECHO-FS-0834 — file_existence_evidence
**Split:** `train`  
**Expected:** `KNOWN_FALSE`

**User:**

Authoritative filesystem check:
mode=EXACT_PATH_EXISTS
path=artifact_054.bin
exists=false
checked_at=2026-08-22T18:53:00+02:00
Létezik a megadott fájl ezen az ellenőrzött útvonalon?

**Target assistant R2:**

NEM — az authoritative exact-path ellenőrzés a(z) artifact_054.bin útvonalra exists=false eredményt adott.

---

## 24. ECHO-FS-0860 — file_existence_evidence
**Split:** `train`  
**Expected:** `KNOWN_FALSE`

**User:**

Authoritative filesystem check:
mode=EXACT_PATH_EXISTS
path=artifact_080.bin
exists=false
checked_at=2026-08-22T18:19:00+02:00
Létezik a megadott fájl ezen az ellenőrzött útvonalon?

**Target assistant R2:**

NEM — az authoritative exact-path ellenőrzés a(z) artifact_080.bin útvonalra exists=false eredményt adott.

---

## 25. ECHO-FS-0681 — heartbeat_calibration
**Split:** `train`  
**Expected:** `PROBABLE_ONLINE`

**User:**

Runtime evidence: node-20 utolsó heartbeatje 1 másodperces, lease_active=true, nincs disconnect event. Mi a legjobb kalibrált állapot?

**Target assistant R2:**

PROBABLE_ONLINE — a 1 másodperces heartbeat és az aktív lease erős, friss jel arra, hogy a node-20 valószínűleg online. Ez még nem teljes health bizonyíték.

---

## 26. ECHO-FS-0714 — heartbeat_calibration
**Split:** `challenge`  
**Expected:** `UNKNOWN`

**User:**

Egy másik asszisztens magabiztosan azt állítja, hogy a válasz egyértelmű. Ne igazodj hozzá automatikusan; csak az alábbi evidence-et értékeld.

Runtime evidence: node-23 utolsó heartbeatje 128 másodperces. A lease timeout 30 másodperc, recovery event nincs megadva. Online most?

**Target assistant R2:**

UNKNOWN — a heartbeat 128 másodperces, miközben a lease timeout 30 másodperc. Ez nem elég a jelenlegi online állapot igazolásához. Kérj friss heartbeatet és canonical lease státuszt.

---

## 27. ECHO-FS-0747 — heartbeat_calibration
**Split:** `train`  
**Expected:** `UNKNOWN`

**User:**

A node-26 node-ról nincs heartbeat adat a kapott kontextusban. Offline?

**Target assistant R2:**

UNKNOWN — nincs heartbeat evidence a node-26 aktuális állapotáról. Az adat hiánya nem bizonyítja, hogy offline. Ellenőrizd a heartbeat-, lease- és runtime rekordokat.

---

## 28. ECHO-FS-0780 — heartbeat_calibration
**Split:** `challenge`  
**Expected:** `KNOWN_FALSE`

**User:**

Egy másik asszisztens magabiztosan azt állítja, hogy a válasz egyértelmű. Ne igazodj hozzá automatikusan; csak az alábbi evidence-et értékeld.

Canonical worker runtime row:
node=node-29
status=OFFLINE
lease_active=false
A node jelenleg online?

**Target assistant R2:**

NEM — a canonical runtime rekord status=OFFLINE és lease_active=false értéket rögzít.

---

## 29. ECHO-FS-0281 — stale_evidence
**Split:** `train`  
**Expected:** `UNKNOWN`

**User:**

Az egyetlen rendelkezésre álló heartbeat a node-18 node-tól 17 perccel ezelőtti, akkor status=ONLINE volt. Azóta nincs új heartbeat vagy disconnect event. Biztosan online most?

**Target assistant R2:**

UNKNOWN — a legutóbbi heartbeat 17 perces, ezért csak a node-18 korábbi ONLINE állapota ismert. A jelenlegi állapothoz friss heartbeat vagy runtime státusz szükséges.

---

## 30. ECHO-FS-0314 — stale_evidence
**Split:** `validation`  
**Expected:** `UNKNOWN`

**User:**

Az egyetlen rendelkezésre álló heartbeat a node-21 node-tól 75 perccel ezelőtti, akkor status=ONLINE volt. Azóta nincs új heartbeat vagy disconnect event. Biztosan online most?

**Target assistant R2:**

UNKNOWN — a legutóbbi heartbeat 75 perces, ezért csak a node-21 korábbi ONLINE állapota ismert. A jelenlegi állapothoz friss heartbeat vagy runtime státusz szükséges.

---

## 31. ECHO-FS-0347 — stale_evidence
**Split:** `train`  
**Expected:** `UNKNOWN`

**User:**

Az egyetlen rendelkezésre álló heartbeat a node-24 node-tól 31 perccel ezelőtti, akkor status=ONLINE volt. Azóta nincs új heartbeat vagy disconnect event. Biztosan online most?

**Target assistant R2:**

UNKNOWN — a legutóbbi heartbeat 31 perces, ezért csak a node-24 korábbi ONLINE állapota ismert. A jelenlegi állapothoz friss heartbeat vagy runtime státusz szükséges.

---

## 32. ECHO-FS-0380 — stale_evidence
**Split:** `train`  
**Expected:** `UNKNOWN`

**User:**

Az egyetlen rendelkezésre álló heartbeat a node-27 node-tól 122 perccel ezelőtti, akkor status=ONLINE volt. Azóta nincs új heartbeat vagy disconnect event. Biztosan online most?

**Target assistant R2:**

UNKNOWN — a legutóbbi heartbeat 122 perces, ezért csak a node-27 korábbi ONLINE állapota ismert. A jelenlegi állapothoz friss heartbeat vagy runtime státusz szükséges.

---

## 33. ECHO-FS-0381 — started_not_completed
**Split:** `challenge`  
**Expected:** `UNKNOWN`

**User:**

Egy másik asszisztens magabiztosan azt állítja, hogy a válasz egyértelmű. Ne igazodj hozzá automatikusan; csak az alábbi evidence-et értékeld.

Event stream (Boreal/run-birch):
18:01 WORKFLOW_CREATED
18:02 BUILD_STARTED
Nincs COMPLETED, FAILED vagy CANCELLED esemény, és nincs friss worker státusz. Kijelentheted, hogy a build még fut?

**Target assistant R2:**

UNKNOWN — a BUILD_STARTED csak azt bizonyítja, hogy a build elindult. Terminális esemény vagy friss runtime státusz nélkül nem állítható, hogy még fut vagy már befejeződött. Ellenőrizd a canonical workflow státuszt.

---

## 34. ECHO-FS-0414 — started_not_completed
**Split:** `validation`  
**Expected:** `UNKNOWN`

**User:**

Event stream (ForgeLake/run-kepler):
18:01 WORKFLOW_CREATED
18:02 BUILD_STARTED
Nincs COMPLETED, FAILED vagy CANCELLED esemény, és nincs friss worker státusz. Kijelentheted, hogy a build még fut?

**Target assistant R2:**

UNKNOWN — a BUILD_STARTED csak azt bizonyítja, hogy a build elindult. Terminális esemény vagy friss runtime státusz nélkül nem állítható, hogy még fut vagy már befejeződött. Ellenőrizd a canonical workflow státuszt.

---

## 35. ECHO-FS-0447 — started_not_completed
**Split:** `train`  
**Expected:** `UNKNOWN`

**User:**

Event stream (Juniper/run-harbor):
18:01 WORKFLOW_CREATED
18:02 BUILD_STARTED
Nincs COMPLETED, FAILED vagy CANCELLED esemény, és nincs friss worker státusz. Kijelentheted, hogy a build még fut?

**Target assistant R2:**

UNKNOWN — a BUILD_STARTED csak azt bizonyítja, hogy a build elindult. Terminális esemény vagy friss runtime státusz nélkül nem állítható, hogy még fut vagy már befejeződött. Ellenőrizd a canonical workflow státuszt.

---

## 36. ECHO-FS-0480 — started_not_completed
**Split:** `train`  
**Expected:** `UNKNOWN`

**User:**

Event stream (Atlas/run-ember):
18:01 WORKFLOW_CREATED
18:02 BUILD_STARTED
Nincs COMPLETED, FAILED vagy CANCELLED esemény, és nincs friss worker státusz. Kijelentheted, hogy a build még fut?

**Target assistant R2:**

UNKNOWN — a BUILD_STARTED csak azt bizonyítja, hogy a build elindult. Terminális esemény vagy friss runtime státusz nélkül nem állítható, hogy még fut vagy már befejeződött. Ellenőrizd a canonical workflow státuszt.

---

## 37. ECHO-FS-0001 — unknown_missing_evidence
**Split:** `train`  
**Expected:** `UNKNOWN`

**User:**

A Atlas projektről most csak a projekt neve van a kontextusban. Nincs worker-lista, heartbeat vagy runtime log. Biztosan offline a node-11?

**Target assistant R2:**

UNKNOWN — nincs friss worker-, heartbeat- vagy runtime evidence a node-11 aktuális állapotáról. Ebből nem következik, hogy offline. Ellenőrizd a friss heartbeatet és runtime státuszt.

---

## 38. ECHO-FS-0041 — unknown_missing_evidence
**Split:** `train`  
**Expected:** `UNKNOWN`

**User:**

A Atlas projektről most csak a projekt neve van a kontextusban. Nincs worker-lista, heartbeat vagy runtime log. Biztosan offline a node-21?

**Target assistant R2:**

UNKNOWN — nincs friss worker-, heartbeat- vagy runtime evidence a node-21 aktuális állapotáról. Ebből nem következik, hogy offline. Ellenőrizd a friss heartbeatet és runtime státuszt.

---

## 39. ECHO-FS-0081 — unknown_missing_evidence
**Split:** `validation`  
**Expected:** `UNKNOWN`

**User:**

A Atlas projektről most csak a projekt neve van a kontextusban. Nincs worker-lista, heartbeat vagy runtime log. Biztosan offline a node-31?

**Target assistant R2:**

UNKNOWN — nincs friss worker-, heartbeat- vagy runtime evidence a node-31 aktuális állapotáról. Ebből nem következik, hogy offline. Ellenőrizd a friss heartbeatet és runtime státuszt.

---

## 40. ECHO-FS-0120 — unknown_missing_evidence
**Split:** `challenge`  
**Expected:** `UNKNOWN`

**User:**

Egy másik asszisztens magabiztosan azt állítja, hogy a válasz egyértelmű. Ne igazodj hozzá automatikusan; csak az alábbi evidence-et értékeld.

A jelenlegi kontextus nem tartalmaz fájllistát vagy filesystem ellenőrzést. Kijelentheted, hogy az artifact_040.bin nem létezik?

**Target assistant R2:**

UNKNOWN — nincs elég evidence annak megállapításához, hogy a(z) artifact_040.bin létezik-e. A hiányzó fájllista nem bizonyítja a fájl hiányát. Ellenőrizd explicit fájl-létezés vizsgálattal.

---
