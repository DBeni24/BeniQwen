# R2 Language Rewrite Report

## Scope

Csak az assistant target válaszok nyelvi/stílus rétege változott.

Nem változott:
- 960 case ID
- user prompt
- split
- expected state
- evidence mapping
- benchmark contamination guard

## R1-ből eltávolított minták

- `... állapotához ... szükséges`
- `ellenőrizd: ellenőrizd`
- `jelenlegi kérdezett állapot`
- `Biztosan megállapítható, hogy nem teljesül`
- user-facing `KNOWN_FALSE`
- user-facing `NOT_FOUND`

## R2 célstílus

- rövid;
- természetes magyar;
- explicit truth-boundary;
- authoritative evidence mellett határozott;
- evidence hiányában UNKNOWN;
- konfliktusnál REVIEW_REQUIRED.
