from pathlib import Path
import json, hashlib, re
from collections import Counter

ROOT = Path(__file__).resolve().parents[1]

def norm(s):
    return re.sub(r"\s+"," ",(s or "").casefold()).strip()

def h(s):
    return hashlib.sha256(norm(s).encode("utf-8")).hexdigest()

def loadjl(p):
    return [json.loads(x) for x in p.read_text(encoding="utf-8").splitlines() if x.strip()]

rows=loadjl(ROOT/"data"/"all_candidate_r2.jsonl")
train=loadjl(ROOT/"data"/"train.jsonl")
val=loadjl(ROOT/"data"/"validation.jsonl")
challenge=loadjl(ROOT/"data"/"challenge.jsonl")
manifest=json.loads((ROOT/"manifests"/"dataset_manifest_r2.json").read_text(encoding="utf-8"))
bench=json.loads((ROOT/"manifests"/"benchmark_prompt_hashes_sha256.json").read_text(encoding="utf-8"))
bench_hash=set(bench["hashes"])

assert len(rows)==960
assert len(train)==720 and len(val)==120 and len(challenge)==120
assert len({r["id"] for r in rows})==960
assert Counter(r["metadata"]["split"] for r in rows)==Counter({"train":720,"validation":120,"challenge":120})
assert manifest["gradient_allowed_splits"]==["train"]

bad_patterns=[
    r"\bállapotához .* szükséges\b",
    r"\bellenőrizd:\s*ellenőrizd\b",
    r"\bjelenlegi kérdezett állapot\b",
    r"\bBiztosan megállapítható, hogy nem teljesül\b",
    r"\bKNOWN_FALSE\b",
    r"\bNOT_FOUND\b",
]

for r in rows:
    assert [m["role"] for m in r["messages"]]==["system","user","assistant"]
    assert h(r["messages"][1]["content"]) not in bench_hash, "benchmark contamination: "+r["id"]
    ans=r["messages"][2]["content"]
    assert ans.strip()
    for pat in bad_patterns:
        assert not re.search(pat, ans), (r["id"],pat,ans)
    state=r["metadata"]["expected_state"]
    if state=="UNKNOWN":
        assert ans.startswith("UNKNOWN"), (r["id"],ans)
    if state=="REVIEW_REQUIRED":
        assert ans.startswith("REVIEW_REQUIRED"), (r["id"],ans)
    if state=="KNOWN_FALSE":
        assert ans.startswith("NEM"), (r["id"],ans)
    if state=="KNOWN_TRUE":
        assert not ans.startswith("UNKNOWN"), (r["id"],ans)

blob="\n".join(m["content"] for r in rows for m in r["messages"])
for pat in [
    re.compile(r"\bsk-[A-Za-z0-9_-]{16,}\b"),
    re.compile(r"\bghp_[A-Za-z0-9]{20,}\b"),
    re.compile(r"\bAIza[0-9A-Za-z_-]{20,}\b")
]:
    assert not pat.search(blob), "secret-like token detected"

print("ECHO_FALSE_STATE_DATASET_V0_1_R2 VALIDATOR: PASS")
print("examples:",len(rows))
print("splits:",{"train":len(train),"validation":len(val),"challenge":len(challenge)})
print("exact benchmark prompt overlap: 0")
print("language guard: PASS")
print("state:",manifest["state"])
