# Echo Cloud Training Bootstrap v1

## Cél

Gyors, kontrollált első fizetős P0 false-state LoRA kör az official `Qwen/Qwen3.5-9B` modellen.

## Állapot

- cloud bootstrap: KÓDBAN LÉTEZIK ebben a csomagban
- frozen dataset: még human review R2 PASS után hozható létre
- training: NINCS ELINDÍTVA
- checkpoint: NINCS
- merge/quant: NINCS IMPLEMENTÁLVA ebben a fázisban

## Könyvtár a cloud gépen

Csomagold ki ide:

`/workspace/echo/bootstrap`

A FROZEN datasetet ide:

`/workspace/echo/dataset`

## Kritikus sorrend

```bash
cd /workspace/echo/bootstrap

bash cloud/scripts/00_bootstrap.sh
bash cloud/scripts/01_download_model.sh
bash cloud/scripts/02_inspect_modules.sh

# dataset feltöltés után:
bash cloud/RUN_TO_DRYRUN.sh
```

Csak ha `DRYRUN_PASS`:

```bash
bash cloud/RUN_P0_TRAINING.sh
```

## Training policy

- official post-trained `Qwen/Qwen3.5-9B`
- BF16 LoRA elsődleges cél 80 GB GPU-n
- vision tower explicit frozen
- csak a tényleges `model.language_model` alatti `nn.Linear` module-ok kapnak LoRA-t
- target module lista actual architecture inspectionből készül
- adapter-only save
- validation/challenge nincs gradientben
- checkpoint eredménye csak `CHECKPOINT_CANDIDATE`
- benchmark előtt nincs merge/freeze

## Miért nem `all-linear` közvetlenül?

A teljes multimodális modellen az `all-linear` a vision tower moduljait is elérhetné. Ezért exact text-backbone target listát generálunk.

## Fast kernel

Qwen3.5 fallback PyTorch implementációval is működik. Az első dry-runba szándékosan nem teszünk FLA/causal-conv1d kötelező függőséget, mert előbb a correctness gate fontos. Ha a dry-run stabil, külön performance-optimalizációként lehet bekapcsolni.
