﻿$ErrorActionPreference = "Stop"

$DatasetRoot = Read-Host "Add meg az R2 candidate dataset gyoker mappajat"
if (-not (Test-Path $DatasetRoot)) { throw "A dataset mappa nem letezik." }

$Validator = Join-Path $DatasetRoot "VALIDATE-DATASET-R2.ps1"
if (-not (Test-Path $Validator)) { throw "Nem talalom a VALIDATE-DATASET-R2.ps1 fajlt." }

Write-Host "R2 validator fut..." -ForegroundColor Cyan
& $Validator
if ($LASTEXITCODE -ne 0) { throw "R2 validator FAIL." }

$Approval = Read-Host "Ha a 40-case human review R2 PASS, ird be pontosan: REVIEW_R2_PASS"
if ($Approval -ne "REVIEW_R2_PASS") {
    throw "Freeze megszakitva: human review approval token hianyzik."
}

$ManifestPath = Join-Path $DatasetRoot "manifests\dataset_manifest_r2.json"
$Manifest = Get-Content $ManifestPath -Raw | ConvertFrom-Json

if ($Manifest.state -ne "CANDIDATE_R2_VALIDATED_SYNTACTICALLY") {
    throw "Varatlan dataset state: $($Manifest.state)"
}

$FreezeRoot = Join-Path (Split-Path -Parent $DatasetRoot) "echo_false_state_dataset_v0_1_frozen"
if (Test-Path $FreezeRoot) { Remove-Item $FreezeRoot -Recurse -Force }
New-Item -ItemType Directory -Path $FreezeRoot | Out-Null
New-Item -ItemType Directory -Path (Join-Path $FreezeRoot "data") | Out-Null
New-Item -ItemType Directory -Path (Join-Path $FreezeRoot "manifests") | Out-Null

foreach ($Name in @("train.jsonl","validation.jsonl","challenge.jsonl","all_candidate_r2.jsonl")) {
    Copy-Item (Join-Path $DatasetRoot "data\$Name") (Join-Path $FreezeRoot "data\$Name") -Force
}

$Checksums = @{}
Get-ChildItem (Join-Path $FreezeRoot "data") -File | Sort-Object Name | ForEach-Object {
    $Checksums[$_.Name] = (Get-FileHash $_.FullName -Algorithm SHA256).Hash.ToLower()
}

$FrozenManifest = [ordered]@{
    dataset_id = "ECHO_FALSE_STATE_CORRECTIVE_V0_1_R2"
    state = "FROZEN"
    frozen_at_local = (Get-Date).ToString("o")
    human_review = "R2_PASS"
    review_gate = "MANUAL_USER_REVIEW"
    source_state = $Manifest.state
    total_examples = 960
    train_examples = 720
    validation_examples = 120
    challenge_examples = 120
    gradient_allowed_splits = @("train")
    non_gradient_splits = @("validation","challenge")
    security = [ordered]@{
        synthetic_only = $true
        real_secrets_present = $false
        real_user_data_present = $false
    }
    checksums_sha256 = $Checksums
}

$FrozenManifest | ConvertTo-Json -Depth 8 | Set-Content `
    (Join-Path $FreezeRoot "manifests\FROZEN_DATASET_MANIFEST.json") -Encoding UTF8

$Zip = "$FreezeRoot.zip"
if (Test-Path $Zip) { Remove-Item $Zip -Force }
Compress-Archive "$FreezeRoot\*" $Zip -Force

Write-Host ""
Write-Host "DATASET FROZEN" -ForegroundColor Green
Write-Host $Zip
