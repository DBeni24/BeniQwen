#!/usr/bin/env bash
set -euo pipefail
WORK=/workspace/echo
BOOT=$WORK/bootstrap
source "$WORK/venv/bin/activate"

if [ ! -f "$WORK/DRYRUN_PASS.json" ]; then
  echo "DRYRUN_PASS.json missing"
  exit 2
fi

python "$BOOT/cloud/scripts/03_verify_frozen_dataset.py" "$WORK/dataset"
cd "$BOOT/cloud/scripts"
python 05_train_p0.py

echo "P0 training finished as CHECKPOINT_CANDIDATE. Do not merge/freeze before benchmark."
