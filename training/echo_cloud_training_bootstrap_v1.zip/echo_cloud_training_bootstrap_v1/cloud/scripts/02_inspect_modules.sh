#!/usr/bin/env bash
set -euo pipefail
source /workspace/echo/venv/bin/activate
python /workspace/echo/bootstrap/cloud/scripts/02_inspect_modules.py
