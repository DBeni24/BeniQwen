from pathlib import Path
import json, torch
from torch.utils.data import Dataset
from transformers import AutoTokenizer

class EchoDataset(Dataset):
    def __init__(self, jsonl_path, tokenizer, max_len):
        self.rows=[json.loads(x) for x in Path(jsonl_path).read_text(encoding="utf-8-sig").splitlines() if x.strip()]
        self.tok=tokenizer
        self.max_len=max_len

    def __len__(self): return len(self.rows)

    def __getitem__(self, idx):
        r=self.rows[idx]
        msgs=r["messages"]
        prefix=self.tok.apply_chat_template(msgs[:-1], tokenize=True, add_generation_prompt=True)
        full=self.tok.apply_chat_template(msgs, tokenize=True, add_generation_prompt=False)
        if full[:len(prefix)] != prefix:
            # Strict guard: don't silently train on misaligned labels.
            raise RuntimeError(f"CHAT_TEMPLATE_PREFIX_MISMATCH:{r['id']}")
        full=full[:self.max_len]
        prompt_len=min(len(prefix),len(full))
        labels=[-100]*prompt_len + full[prompt_len:]
        return {"input_ids":full,"attention_mask":[1]*len(full),"labels":labels,"id":r["id"]}

class Collator:
    def __init__(self, tokenizer):
        self.tok=tokenizer
        if self.tok.pad_token_id is None:
            self.tok.pad_token=self.tok.eos_token
    def __call__(self,batch):
        maxlen=max(len(x["input_ids"]) for x in batch)
        pad=self.tok.pad_token_id
        ids=[]; masks=[]; labels=[]
        for x in batch:
            n=maxlen-len(x["input_ids"])
            ids.append(x["input_ids"]+[pad]*n)
            masks.append(x["attention_mask"]+[0]*n)
            labels.append(x["labels"]+[-100]*n)
        return {
            "input_ids":torch.tensor(ids,dtype=torch.long),
            "attention_mask":torch.tensor(masks,dtype=torch.long),
            "labels":torch.tensor(labels,dtype=torch.long),
        }

def load_targets(path="/workspace/echo/module_inspection.json"):
    return json.loads(Path(path).read_text())["target_modules"]
