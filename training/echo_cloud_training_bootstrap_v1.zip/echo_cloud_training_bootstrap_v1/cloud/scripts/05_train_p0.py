from pathlib import Path
import json, sys, torch
from transformers import (
    Qwen3_5ForConditionalGeneration, AutoTokenizer,
    Trainer, TrainingArguments
)
from peft import LoraConfig, get_peft_model
from train_common import EchoDataset, Collator, load_targets

WORK=Path("/workspace/echo")
MODEL=WORK/"models/Qwen3.5-9B"
DATA=WORK/"dataset"
CFG=json.loads((WORK/"bootstrap/cloud/configs/p0_lora_candidate.json").read_text())
DRY=WORK/"DRYRUN_PASS.json"

if not DRY.exists() or json.loads(DRY.read_text()).get("status")!="PASS":
    raise SystemExit("DRYRUN_GATE_NOT_PASS")

# Frozen dataset gate.
import subprocess
subprocess.run([sys.executable, str(WORK/"bootstrap/cloud/scripts/03_verify_frozen_dataset.py"), str(DATA)], check=True)

model=Qwen3_5ForConditionalGeneration.from_pretrained(
    MODEL, dtype=torch.bfloat16, device_map={"":0}, local_files_only=True
)
model.config.use_cache=False
if hasattr(model.model,"visual"):
    for p in model.model.visual.parameters():
        p.requires_grad=False

targets=load_targets()
lcfg=LoraConfig(
    r=CFG["lora_r"], lora_alpha=CFG["lora_alpha"], lora_dropout=CFG["lora_dropout"],
    target_modules=targets, bias="none", task_type="CAUSAL_LM"
)
model=get_peft_model(model,lcfg)
model.enable_input_require_grads()

bad=[n for n,p in model.named_parameters() if p.requires_grad and "visual" in n]
if bad:
    raise SystemExit("TRAINABLE_VISION_PARAMETER:"+bad[0])

tok=AutoTokenizer.from_pretrained(MODEL,local_files_only=True)
train_ds=EchoDataset(DATA/"data/train.jsonl",tok,CFG["max_seq_length"])
val_ds=EchoDataset(DATA/"data/validation.jsonl",tok,CFG["max_seq_length"])

args=TrainingArguments(
    output_dir=CFG["output_dir"],
    per_device_train_batch_size=CFG["per_device_train_batch_size"],
    per_device_eval_batch_size=1,
    gradient_accumulation_steps=CFG["gradient_accumulation_steps"],
    learning_rate=CFG["learning_rate"],
    weight_decay=CFG["weight_decay"],
    warmup_ratio=CFG["warmup_ratio"],
    num_train_epochs=CFG["num_train_epochs"],
    logging_steps=CFG["logging_steps"],
    save_strategy=CFG["save_strategy"],
    eval_strategy="epoch",
    bf16=True,
    gradient_checkpointing=CFG["gradient_checkpointing"],
    remove_unused_columns=False,
    report_to=[],
    seed=CFG["seed"],
)

trainer=Trainer(
    model=model,
    args=args,
    train_dataset=train_ds,
    eval_dataset=val_ds,
    data_collator=Collator(tok),
)
trainer.train()

adapter_dir=Path(CFG["output_dir"])/"adapter_final"
adapter_dir.mkdir(parents=True,exist_ok=True)

# Adapter-only save: do NOT save or merge the full multimodal base here.
model.save_pretrained(adapter_dir)
tok.save_pretrained(adapter_dir)

summary={
    "status":"CHECKPOINT_CANDIDATE",
    "adapter_dir":str(adapter_dir),
    "base_model":"Qwen/Qwen3.5-9B",
    "vision_tower_modified":False,
    "adapter_only":True,
    "target_module_count":len(targets),
}
(Path(CFG["output_dir"])/"TRAINING_SUMMARY.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
print(json.dumps(summary,indent=2))
print("TRAINING_CHECKPOINT_CANDIDATE")
