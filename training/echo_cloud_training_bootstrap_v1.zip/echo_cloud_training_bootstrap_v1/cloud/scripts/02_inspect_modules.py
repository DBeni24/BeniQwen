from pathlib import Path
import json
import torch
from accelerate import init_empty_weights
from transformers import AutoConfig, Qwen3_5ForConditionalGeneration

MODEL_DIR=Path("/workspace/echo/models/Qwen3.5-9B")
OUT=Path("/workspace/echo/module_inspection.json")

cfg=AutoConfig.from_pretrained(MODEL_DIR, local_files_only=True)
with init_empty_weights():
    model=Qwen3_5ForConditionalGeneration(cfg)

targets=[]
vision_linear=[]
all_linear=[]
for name,module in model.named_modules():
    if isinstance(module, torch.nn.Linear):
        all_linear.append(name)
        if name.startswith("model.language_model.") and not name.endswith("lm_head"):
            targets.append(name)
        if ".visual." in name or name.startswith("model.visual."):
            vision_linear.append(name)

if not targets:
    raise SystemExit("NO_TEXT_LINEAR_TARGETS_FOUND")
if any("visual" in x for x in targets):
    raise SystemExit("VISION_TARGET_LEAK")

suffix_counts={}
for n in targets:
    suffix=n.split(".")[-1]
    suffix_counts[suffix]=suffix_counts.get(suffix,0)+1

report={
    "model_class":type(model).__name__,
    "model_type":cfg.model_type,
    "text_layers":getattr(cfg.text_config,"num_hidden_layers",None),
    "vision_present":hasattr(cfg,"vision_config"),
    "text_linear_target_count":len(targets),
    "vision_linear_count":len(vision_linear),
    "target_suffix_counts":dict(sorted(suffix_counts.items())),
    "target_modules":targets,
    "policy":"Exact text-backbone nn.Linear module names only. Vision tower excluded.",
}
OUT.write_text(json.dumps(report,indent=2),encoding="utf-8")
print(json.dumps({k:v for k,v in report.items() if k!="target_modules"},indent=2))
print("MODULE_INSPECTION_PASS")
