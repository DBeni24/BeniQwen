from pathlib import Path
import json, time, torch, sys
from transformers import Qwen3_5ForConditionalGeneration, AutoTokenizer
from peft import LoraConfig, get_peft_model
from torch.utils.data import DataLoader
from train_common import EchoDataset, Collator, load_targets

WORK=Path("/workspace/echo")
MODEL=WORK/"models/Qwen3.5-9B"
DATA=WORK/"dataset"
CFG=json.loads((WORK/"bootstrap/cloud/configs/p0_lora_candidate.json").read_text())
OUT=WORK/"DRYRUN_PASS.json"

# Frozen dataset gate.
import subprocess
subprocess.run([sys.executable, str(WORK/"bootstrap/cloud/scripts/03_verify_frozen_dataset.py"), str(DATA)], check=True)

torch.cuda.empty_cache()
model=Qwen3_5ForConditionalGeneration.from_pretrained(
    MODEL, dtype=torch.bfloat16, device_map={"":0}, local_files_only=True
)
model.config.use_cache=False

# Explicitly freeze vision tower.
if hasattr(model.model,"visual"):
    for p in model.model.visual.parameters():
        p.requires_grad=False

targets=load_targets()
lcfg=LoraConfig(
    r=CFG["lora_r"], lora_alpha=CFG["lora_alpha"], lora_dropout=CFG["lora_dropout"],
    target_modules=targets, bias="none", task_type="CAUSAL_LM"
)
model=get_peft_model(model,lcfg)
model.enable_input_require_grads()
model.gradient_checkpointing_enable()
model.train()

# Hard guard: no trainable visual parameter.
bad=[n for n,p in model.named_parameters() if p.requires_grad and "visual" in n]
if bad:
    raise SystemExit("TRAINABLE_VISION_PARAMETER:"+bad[0])

tok=AutoTokenizer.from_pretrained(MODEL,local_files_only=True)
ds=EchoDataset(DATA/"data/train.jsonl",tok,CFG["max_seq_length"])
loader=DataLoader(ds,batch_size=1,shuffle=False,collate_fn=Collator(tok))
opt=torch.optim.AdamW((p for p in model.parameters() if p.requires_grad),lr=CFG["learning_rate"])

steps=int(CFG["dry_run_steps"])
losses=[]
peak=0
start=time.time()
for step,batch in enumerate(loader,1):
    if step>steps: break
    batch={k:v.cuda() for k,v in batch.items()}
    out=model(**batch)
    loss=out.loss
    if not torch.isfinite(loss):
        raise SystemExit("NON_FINITE_LOSS")
    loss.backward()
    opt.step(); opt.zero_grad(set_to_none=True)
    losses.append(float(loss.detach().cpu()))
    peak=max(peak,torch.cuda.max_memory_allocated())
    print(f"step={step} loss={losses[-1]:.6f} peak_gib={peak/1024**3:.2f}")

report={
    "status":"PASS",
    "steps":len(losses),
    "losses":losses,
    "peak_allocated_gib":round(peak/1024**3,2),
    "elapsed_seconds":round(time.time()-start,2),
    "trainable_params":sum(p.numel() for p in model.parameters() if p.requires_grad),
    "vision_trainable_params":0,
    "target_module_count":len(targets),
}
OUT.write_text(json.dumps(report,indent=2),encoding="utf-8")
print(json.dumps(report,indent=2))
print("DRYRUN_PASS")
