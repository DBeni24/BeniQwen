from pathlib import Path
import json, hashlib, sys

ROOT=Path(sys.argv[1]) if len(sys.argv)>1 else Path("/workspace/echo/dataset")
manifest_path=ROOT/"manifests"/"FROZEN_DATASET_MANIFEST.json"
if not manifest_path.exists():
    raise SystemExit("FROZEN_MANIFEST_MISSING")
m=json.loads(manifest_path.read_text(encoding="utf-8-sig"))
if m.get("state")!="FROZEN":
    raise SystemExit("DATASET_NOT_FROZEN")
if m.get("human_review")!="R2_PASS":
    raise SystemExit("R2_HUMAN_REVIEW_NOT_PASS")

for name,expected in m["checksums_sha256"].items():
    p=ROOT/"data"/name
    if not p.exists():
        raise SystemExit("MISSING_DATA_FILE:"+name)
    actual=hashlib.sha256(p.read_bytes()).hexdigest().lower()
    if actual!=expected.lower():
        raise SystemExit("CHECKSUM_FAIL:"+name)

print("FROZEN_DATASET_PASS")
print("train",m["train_examples"],"validation",m["validation_examples"],"challenge",m["challenge_examples"])
