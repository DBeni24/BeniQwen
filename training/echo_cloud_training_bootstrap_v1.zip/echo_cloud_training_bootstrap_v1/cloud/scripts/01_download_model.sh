#!/usr/bin/env bash
set -euo pipefail
WORK=/workspace/echo
VENV=$WORK/venv
MODEL_DIR=$WORK/models/Qwen3.5-9B
source "$VENV/bin/activate"
mkdir -p "$WORK/models"

echo "Downloading official Qwen/Qwen3.5-9B..."
hf download Qwen/Qwen3.5-9B --local-dir "$MODEL_DIR"

python - <<'PY'
from pathlib import Path
p=Path("/workspace/echo/models/Qwen3.5-9B")
need=["config.json","tokenizer_config.json"]
for n in need:
    if not (p/n).exists():
        raise SystemExit("MISSING:"+n)
print("MODEL_DOWNLOAD_PASS")
PY
