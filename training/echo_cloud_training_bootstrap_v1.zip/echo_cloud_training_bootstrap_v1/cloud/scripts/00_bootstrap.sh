#!/usr/bin/env bash
set -euo pipefail

WORK=/workspace/echo
VENV=$WORK/venv
mkdir -p "$WORK"

echo "=== GPU ==="
nvidia-smi

echo "=== Python ==="
python3 --version

if [ ! -d "$VENV" ]; then
  python3 -m venv --system-site-packages "$VENV"
fi
source "$VENV/bin/activate"

python -m pip install -U pip setuptools wheel

# Reuse the provider image's working CUDA/PyTorch stack; do not blindly replace torch.
python - <<'PY'
import torch
print("torch", torch.__version__)
print("cuda", torch.cuda.is_available())
if not torch.cuda.is_available():
    raise SystemExit("CUDA_NOT_AVAILABLE")
print("gpu", torch.cuda.get_device_name(0))
print("bf16", torch.cuda.is_bf16_supported())
PY

python -m pip install -U \
  "transformers>=5.13,<5.16" \
  peft trl accelerate datasets bitsandbytes \
  safetensors huggingface_hub sentencepiece psutil

python - <<'PY'
import torch, transformers, peft, trl, accelerate, bitsandbytes, huggingface_hub
print("TRAINING_STACK_OK")
print("transformers", transformers.__version__)
print("peft", peft.__version__)
print("trl", trl.__version__)
print("accelerate", accelerate.__version__)
PY

python -m pip freeze > "$WORK/requirements.freeze.txt"
echo "BOOTSTRAP_PASS"
