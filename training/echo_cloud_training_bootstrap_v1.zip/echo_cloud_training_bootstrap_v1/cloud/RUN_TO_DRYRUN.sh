#!/usr/bin/env bash
set -euo pipefail
WORK=/workspace/echo
BOOT=$WORK/bootstrap
source "$WORK/venv/bin/activate"

python "$BOOT/cloud/scripts/03_verify_frozen_dataset.py" "$WORK/dataset"
python "$BOOT/cloud/scripts/02_inspect_modules.py"
cd "$BOOT/cloud/scripts"
python 04_dry_run.py

echo "=== DRY RUN RESULT ==="
cat "$WORK/DRYRUN_PASS.json"
