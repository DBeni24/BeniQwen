﻿$ErrorActionPreference="Stop"
$Here=Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Here

$Python="C:\Users\dbene\Downloads\echo_qwen_baseline_v1_environment\.venv\Scripts\python.exe"
if (-not (Test-Path $Python)) { throw "Nem talalom a benchmark .venv Pythonjat." }

Write-Host "=== Qwen source inspection ===" -ForegroundColor Cyan
& $Python ".\preflight\inspect_qwen35_source.py"
if ($LASTEXITCODE -ne 0) { throw "Qwen source inspection FAIL." }

Write-Host "=== Training environment preflight ===" -ForegroundColor Cyan
& $Python ".\preflight\training_env_preflight.py"
if ($LASTEXITCODE -ne 0) { throw "Training environment preflight FAIL." }

$OutDir="TRAINING_PREFLIGHT_UPLOAD"
if (Test-Path $OutDir) { Remove-Item $OutDir -Recurse -Force }
New-Item -ItemType Directory $OutDir | Out-Null
Copy-Item ".\QWEN35_SOURCE_INSPECTION.json" $OutDir
Copy-Item ".\TRAINING_ENV_PREFLIGHT.json" $OutDir
Compress-Archive "$OutDir\*" ".\UPLOAD_ME_ECHO_TRAINING_PREFLIGHT.zip" -Force

Write-Host ""
Write-Host "Feltoltendo preflight fajl:" -ForegroundColor Green
Write-Host (Join-Path $Here "UPLOAD_ME_ECHO_TRAINING_PREFLIGHT.zip")
