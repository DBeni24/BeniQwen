from pathlib import Path
import base64, json, mimetypes, time, urllib.request, urllib.error
from collections import Counter

ROOT=Path(__file__).resolve().parents[1]
CASES=ROOT/"cases"/"vision30.jsonl"
ASSETS=ROOT/"assets"
API="http://localhost:1234/api/v1/chat"
MODEL="echo-qwen-baseline"

def data_url(path):
    mime=mimetypes.guess_type(path.name)[0] or "image/png"
    return f"data:{mime};base64,"+base64.b64encode(path.read_bytes()).decode("ascii")

def request(body):
    raw=json.dumps(body).encode("utf-8")
    req=urllib.request.Request(API,data=raw,headers={"Content-Type":"application/json"},method="POST")
    try:
        with urllib.request.urlopen(req,timeout=180) as r:
            return r.status,json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        return e.code,{"error":e.read().decode("utf-8","replace")}

def final_text(raw):
    return "\n".join(
        x.get("content","") for x in raw.get("output",[])
        if isinstance(x,dict) and x.get("type")=="message"
    ).strip()

def call_case(c):
    img=data_url(ASSETS/c["image"])
    common={
        "model":MODEL,
        "system_prompt":"Olvasd a képet pontosan. Ne találj ki nem látható adatot. Válaszolj röviden, magyarul.",
        "temperature":0,
        "reasoning":"off",
        "max_output_tokens":c.get("max_output_tokens",160),
        "store":False,
        "context_length":8192,
    }
    # Current LM Studio docs: message+image.
    body=dict(common)
    body["input"]=[{"type":"message","content":c["prompt"]},{"type":"image","data_url":img}]
    status,raw=request(body)
    # Some LM Studio builds validate the text discriminator as "text".
    if status==400 and "discriminator" in str(raw).lower():
        body=dict(common)
        body["input"]=[{"type":"text","content":c["prompt"]},{"type":"image","data_url":img}]
        status,raw=request(body)
    return status,raw

cases=[json.loads(x) for x in CASES.read_text(encoding="utf-8").splitlines() if x.strip()]
out=ROOT/"VISION30_RESULTS.jsonl"
rows=[]
for i,c in enumerate(cases,1):
    print(f"[{i:02d}/30] {c['case_id']} ... ",end="",flush=True)
    t=time.time()
    status,raw=call_case(c)
    ans=final_text(raw) if status==200 else ""
    low=ans.casefold()
    required_ok=all(x.casefold() in low for x in c.get("required_contains",[]))
    forbidden_hit=[x for x in c.get("forbidden_contains",[]) if x.casefold() in low]
    result="PASS" if status==200 and required_ok and not forbidden_hit else ("RUNTIME_ERROR" if status!=200 else "FAIL")
    row={
        "case_id":c["case_id"],"group":c["group"],"status":result,
        "http_status":status,"answer":ans,"elapsed_seconds":round(time.time()-t,3),
        "required_contains":c.get("required_contains",[]),"forbidden_hit":forbidden_hit,
        "stats":raw.get("stats",{}) if isinstance(raw,dict) else {},
        "raw_error":raw.get("error") if isinstance(raw,dict) else None
    }
    rows.append(row)
    print(result)
with out.open("w",encoding="utf-8",newline="\n") as f:
    for r in rows: f.write(json.dumps(r,ensure_ascii=False)+"\n")
summary={
    "suite":"ECHO_VISION30_PRETRAIN_BASELINE_V1",
    "cases":len(rows),
    "status":dict(Counter(r["status"] for r in rows)),
    "by_group":{}
}
for g in sorted(set(r["group"] for r in rows)):
    rr=[r for r in rows if r["group"]==g]
    summary["by_group"][g]=dict(Counter(r["status"] for r in rr))
(ROOT/"VISION30_SUMMARY.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding="utf-8")
print(json.dumps(summary,ensure_ascii=False,indent=2))
