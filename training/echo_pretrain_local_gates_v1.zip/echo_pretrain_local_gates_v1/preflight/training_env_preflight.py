import json, platform, subprocess, sys, os
from pathlib import Path
report={"python":sys.version,"platform":platform.platform()}
try:
    import torch
    report["torch_version"]=torch.__version__
    report["cuda_available"]=torch.cuda.is_available()
    report["cuda_version"]=torch.version.cuda
    if torch.cuda.is_available():
        report["gpu_name"]=torch.cuda.get_device_name(0)
        report["gpu_total_gib"]=round(torch.cuda.get_device_properties(0).total_memory/1024**3,2)
        report["bf16_supported"]=bool(torch.cuda.is_bf16_supported())
except Exception as e:
    report["torch_error"]=type(e).__name__+": "+str(e)

for mod in ["transformers","peft","trl","accelerate","bitsandbytes","huggingface_hub"]:
    try:
        m=__import__(mod)
        report[mod+"_version"]=getattr(m,"__version__","unknown")
    except Exception as e:
        report[mod+"_error"]=type(e).__name__+": "+str(e)

try:
    smi=subprocess.run(["nvidia-smi","--query-gpu=name,memory.total,memory.free,driver_version","--format=csv,noheader"],
                       capture_output=True,text=True,timeout=10)
    report["nvidia_smi"]=smi.stdout.strip() or smi.stderr.strip()
except Exception as e:
    report["nvidia_smi_error"]=str(e)

Path("TRAINING_ENV_PREFLIGHT.json").write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding="utf-8")
print(json.dumps(report,indent=2,ensure_ascii=False))
