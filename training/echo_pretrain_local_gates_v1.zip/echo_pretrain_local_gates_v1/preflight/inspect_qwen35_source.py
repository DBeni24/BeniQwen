import json, urllib.request
from pathlib import Path

MODEL="Qwen/Qwen3.5-9B"
URL="https://huggingface.co/Qwen/Qwen3.5-9B/resolve/main/config.json"
with urllib.request.urlopen(URL,timeout=30) as r:
    cfg=json.load(r)

text=cfg.get("text_config",{})
report={
    "model_id":MODEL,
    "architectures":cfg.get("architectures"),
    "model_type":cfg.get("model_type"),
    "vision_present":"vision_config" in cfg,
    "text_hidden_size":text.get("hidden_size"),
    "text_layers":text.get("num_hidden_layers"),
    "intermediate_size":text.get("intermediate_size"),
    "full_attention_interval":text.get("full_attention_interval"),
    "dtype":text.get("dtype"),
    "vocab_size":text.get("vocab_size"),
    "decision":"Use official post-trained full-precision Qwen/Qwen3.5-9B for first corrective LoRA so the training source matches the frozen baseline family.",
    "target_module_status":"NOT_FROZEN_YET: exact PEFT target modules must be confirmed from an actual loaded model/architecture inspection before paid training."
}
Path("QWEN35_SOURCE_INSPECTION.json").write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding="utf-8")
print(json.dumps(report,indent=2,ensure_ascii=False))
