# Echo – Pre-training Local Gates v1

Cél: a fizetős training előtt a minimális lokális gate-ek gyors lezárása.

## Tartalom

1. `RUN-VISION30-PRETRAIN.ps1`
   - 30 kontrollált, szintetikus vision case
   - LM Studio `echo-qwen-baseline`
   - reasoning off, temperature 0
   - a runner két LM Studio v1 image-input text-discriminator formátummal kompatibilis fallbacket használ

2. `RUN-TRAINING-PREFLIGHT.ps1`
   - official `Qwen/Qwen3.5-9B` config inspection
   - lokális Python/PyTorch/CUDA/package inventory
   - nem tölt le modell weights-et
   - nem indít traininget

## Nem része

- dataset freeze (ehhez R2 human review PASS kell)
- fizetős cloud training
- LoRA target module véglegesítés
- model weights letöltése

## Gate sorrend

R2 human review PASS
→ dataset freeze
→ Vision30 pre-training baseline
→ training preflight
→ paid training dry-run
