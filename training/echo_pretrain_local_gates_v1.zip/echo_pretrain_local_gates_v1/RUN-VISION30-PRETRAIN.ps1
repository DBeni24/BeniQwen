﻿$ErrorActionPreference="Stop"
$Here=Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Here

$PsJson = (& lms ps --json 2>&1 | Out-String)
if ($PsJson -notmatch '"identifier":"echo-qwen-baseline"') {
    throw "Az echo-qwen-baseline nincs betoltve."
}

$Python="C:\Users\dbene\Downloads\echo_qwen_baseline_v1_environment\.venv\Scripts\python.exe"
if (-not (Test-Path $Python)) { throw "Nem talalom a benchmark .venv Pythonjat." }

& $Python ".\vision30\runner\run_vision30.py"
if ($LASTEXITCODE -ne 0) { throw "Vision30 runner FAIL." }

$OutDir="VISION30_UPLOAD"
if (Test-Path $OutDir) { Remove-Item $OutDir -Recurse -Force }
New-Item -ItemType Directory $OutDir | Out-Null
Copy-Item ".\vision30\VISION30_RESULTS.jsonl" $OutDir
Copy-Item ".\vision30\VISION30_SUMMARY.json" $OutDir
Copy-Item ".\vision30\cases\vision30.jsonl" $OutDir
Compress-Archive "$OutDir\*" ".\UPLOAD_ME_ECHO_VISION30_PRETRAIN.zip" -Force
Write-Host "Feltoltendo: $(Join-Path $Here 'UPLOAD_ME_ECHO_VISION30_PRETRAIN.zip')" -ForegroundColor Green
